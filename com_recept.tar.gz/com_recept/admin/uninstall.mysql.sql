DROP TABLE IF EXISTS `#__ingredients_article`;

DROP TABLE IF EXISTS `#__ingredients_list`;

DROP TABLE IF EXISTS `#__ingredients_basket`;